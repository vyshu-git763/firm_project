import React from 'react';
import './sebi.css';

const Sebi = () => {
  return (
    <div className="service-page">
      <h1>SEBI Listed Companies</h1>
      <p>Details about the SEBI Listed Companies...</p>
    </div>
  );
};

export default Sebi;