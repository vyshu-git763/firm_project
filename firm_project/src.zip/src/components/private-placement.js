import React from 'react';
import './private-placement.css';

const Privateplacement = () => {
  return (
    <div className="service-page">
      <h1>Private Placement </h1>
      <p>Details about the Private Placement... </p>
    </div>
  );
};

export default Privateplacement;