import React from 'react';
import './insolvency-bankruptcy.css';

const Insolvency = () => {
  return (
    <div className="service-page">
      <h1>Insolvency and Bankruptcy</h1>
      <p>Details about the Insolvency and Bankruptcy...</p>
    </div>
  );
};

export default Insolvency;