import React from 'react';
import './corporate-restructuring.css';

const Corporaterestructuring = () => {
  return (
    <div className="service-page">
      <h1>corporate Restructuring</h1>
      <p>Details about the Corporate Restructuring Services...</p>
    </div>
  );
}; 

export default Corporaterestructuring;