import React from 'react';
import './audit.css';

const Audit = () => {
  return (
    <div className="service-page">
      <h1>Audit and Due Diligence </h1>
      <p>Details about the Audit and Due Diligence...</p>
    </div>
  );
};

export default Audit;